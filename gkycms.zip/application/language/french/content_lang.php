<?php

$lang['ctn_1'] = "Test FRENCH";

?>